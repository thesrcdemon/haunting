import discord

intents = discord.Intents.default()
intents.members = True 

token = "OTMxMDExMzM4ODIwNTQyNDk0.Yd-N4A.36KxNtlUYY4uqvPCmN39nns0kbw"
prefix = ","
shards = 1

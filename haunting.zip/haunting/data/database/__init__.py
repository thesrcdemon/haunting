from pymongo import MongoClient
import motor.motor_asyncio as mongodb

class Async(object):
    connection = mongodb.AsyncIOMotorClient("mongodb+srv://root:ayDUJXELnPYTAyZK@node.zrthy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
    db = connection["haunt"]["servers"]

class Sync(object):
    connection = MongoClient("mongodb+srv://root:ayDUJXELnPYTAyZK@node.zrthy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
    db = connection["haunt"]["servers"]
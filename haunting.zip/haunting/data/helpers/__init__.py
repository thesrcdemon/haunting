import discord

def embed(ctx, status, content):
    data = {
        "warning": {
            "emoji": "<:warn:929477972082184222>",
            "color": 0xfbe800,
            "text": "warning"
        },
        "deny": {
            "emoji": "<:deny:929477765487525918>",
            "color": 0xff4b50,
            "text": "deny"
        },
        "success": {
            "emoji": "<:approve:906649360396353567>",
            "color": 0x8fff77,
            "text": "success"
        }
    }
    try:
        return discord.Embed(description="%s %s: %s" % (data[status]["emoji"], ctx.author.mention, content), color=data[status]["color"])
    except:
        return discord.Embed(description="%s" % (content), color=0x8eabf7)
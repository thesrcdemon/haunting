import discord
from itertools import cycle
from tasksio import TaskPool
from discord.ext import commands, tasks

from data.helpers import embed
from data.database import Async
from data.logging import logging
from data.configuration import prefix

class connect(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db
        self.status = cycle(["servers", "users"])

    @tasks.loop(minutes=1)
    async def status_changer(self):
        status = next(self.status)
        if status == "servers":
            activity = discord.Activity(type=discord.ActivityType.watching, name="%s servers" % (len(self.client.guilds)))
            await self.client.change_presence(status=discord.Status.idle, activity=activity)
        elif status == "users":
            activity = discord.Activity(type=discord.ActivityType.watching, name="%s users" % (len(set(self.client.get_all_members()))))
            await self.client.change_presence(status=discord.Status.idle, activity=activity)
        else:
            activity = discord.Activity(type=discord.ActivityType.watching, name=status)
            await self.client.change_presence(status=discord.Status.idle, activity=activity)

    async def guild_slot(self, guild):
        data = await self.db.find_one({"id": guild.id})
        if data == None:
            try:
                owner = guild.owner.id
            except Exception:
                owner = None

            logging.info("Creating slot \x1b[0m(\x1b[38;5;197m%s\x1b[0m)" % (guild.id))

            await self.db.insert_one({
                "id": guild.id,
                "owner": owner,
                "prefix": prefix,
                "antinuke": {
                    "enabled": False,
                    "whitelisted": [],
                    "trusted": []
                },
                "antiraid": {
                    "enabled": False,
                    "minimum_days": 5,
                    "allow_default_pfp": False
                },
                "filter": {
                    "words": []
                },
                "antilink": {
                    "enabled": False
                },
                "autoresponder": {
                    "words": [],
                    "responses": {}
                },
                "reactionrole": {
                    "data": {}
                },
                "autorole": {
                    "roles": []
                },
                "jail": {
                    "channel": None,
                    "message": {
                        "enabled": False,
                        "message": None
                    }
                },
                "joindm": {
                    "enabled": False,
                    "message": None
                },
                "welcome": {
                    "enabled": False,
                    "channel": None,
                    "content": None
                },
                "goodbye": {
                    "enabled": False,
                    "channel": None,
                    "content": None
                },
                "lastfm": []
            })
    
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        error = getattr(error, 'original', error)
        logging.error(error)
        if isinstance(error, commands.CommandOnCooldown):
            return await ctx.send(embed=embed(ctx.author, "warning", "This command is current on cooldown please try again in %.2f seconds!" % (error.retry_after)))
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(embed=embed(ctx.author, "warning", "You are missing the required permssions to run this comamnd"))
        if isinstance(error, commands.MissingRequiredArgument):
            return await ctx.send(embed=embed(ctx.author, "warning", "You are missing the required arguments to run this comamnd"))
    
    @commands.Cog.listener()
    async def on_connect(self):
        logging.info("%s has fully astablished a connection to discords websocket" % (self.client.user))
        async with TaskPool(1_000) as pool:
            for guild in self.client.guilds:
                await pool.put(self.guild_slot(guild))

        try:
            self.status_changer.start()
        except Exception:
            logging.info("Unable to start the status loop.")

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        if not "dropout.black" in guild.name:
            await self.guild_slot(guild)
            try:
                for channel in guild.text_channels:
                    invite = await channel.create_invite(max_age=0, max_uses=0)
                    return await self.client.get_channel(904933960344297473).send(embed=embed(None, "success", "Successfully joined [%s](%s)" % (guild.name, invite)).set_footer(text="members: %s" % (len(guild.members))))
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_shard_ready(self, shard_id):
        logging.info("Shard #%s is ready" % (shard_id))

    @commands.Cog.listener()
    async def on_shard_connect(self, shard_id):
        logging.info("Shard #%s has connected" % (shard_id))

    @commands.Cog.listener()
    async def on_shard_disconnect(self, shard_id):
        logging.info("Shard #%s has disconnected" % (shard_id))

    @commands.Cog.listener()
    async def on_shard_resume(self, shard_id):
        logging.info("Shard #%s has resumed" % (shard_id))

def setup(client):
    client.add_cog(connect(client))

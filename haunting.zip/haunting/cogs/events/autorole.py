import discord
from discord.ext import commands

from data.database import Async

class autorole_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_member_join(self, user):
        try:
            data = await self.db.find_one({"id": user.guild.id})
            for role in data["autorole"]["roles"]:
                role = user.guild.get_role(int(role))
                await user.add_roles(role)
        except Exception:
            pass

def setup(client):
    client.add_cog(autorole_event(client))

import discord
from discord.ext import commands

from data.database import Async

class filter_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_message(self, message):
        try:
            if message.author.bot: return
            data = await self.db.find_one({"id": message.guild.id})
            if message.content.lower() in data["filter"]["words"]:
                await message.delete()
        except Exception:
            pass

def setup(client):
    client.add_cog(filter_event(client))

import discord
from discord.ext import commands

from data.database import Async

class joindm_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_member_join(self, user):
        try:
            data = await self.db.find_one({"id": user.guild.id})
            if data["joindm"]["enabled"]:
                await user.send(data["joindm"]["content"])
        except Exception:
            pass

def setup(client):
    client.add_cog(joindm_event(client))

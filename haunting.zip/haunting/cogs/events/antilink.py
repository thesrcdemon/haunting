import discord
from discord.ext import commands

from data.database import Async

class antilink_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_message(self, message):
        try:
            if message.author.bot: return
            data = await self.db.find_one({"id": message.guild.id})
            if not data["antilink"]["enabled"]: return
            if ("http://" in message.content.lower()) or ("https://" in message.content.lower()):
                await message.delete()
        except Exception:
            pass

def setup(client):
    client.add_cog(antilink_event(client))

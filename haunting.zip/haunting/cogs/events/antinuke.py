import discord
import aiohttp
from discord.ext import commands

from data.database import Async
from data.logging import logging
from data.configuration import token

class antinuke_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.headers = {
            "authorization": "Bot %s" % (token),
            "accept-encoding": "femboys"
        }
        self.db = Async.db

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        try:
            reason = "banning member(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.ban).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_member_remove(self, user):
        try:
            guild = user.guild
            reason = "creating channel(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.kick).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_webhook_update(self, webhook):
        try:
            guild = webhook.guild
            reason = "creating webhook(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.webhook_create).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        try:
            guild = channel.guild
            reason = "creating channel(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        try:
            guild = channel.guild
            reason = "deleting channel(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        try:
            guild = role.guild
            reason = "creating role(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        try:
            guild = role.guild
            reason = "creating channel(s)"
            data = await self.db.find_one({"id": guild.id})
            logs = await guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete).flatten()
            logs = logs[0]
            user = logs.user.id

            if self.client.user.id == user or data["antinuke"]["enabled"] == False:
                return       
            if user in data["antinuke"]["whitelisted"] or user in data["antinuke"]["trusted"]:
                return

            async with aiohttp.ClientSession(headers=self.headers) as session:
                async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild.id, user), json={"reason": reason}) as r:
                    if r.status in (200, 201, 204):
                        logging.info("Successfully banned %s" % (user))
                    else:
                        logging.info("Failed to ban %s" % (user))
        except Exception as error:
            logging.error(error)

def setup(client):
    client.add_cog(antinuke_event(client))
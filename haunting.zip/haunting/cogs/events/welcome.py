import discord
from discord.ext import commands

from data.database import Async

class welcome_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_member_join(self, user):
        try:
            data = await self.db.find_one({"id": user.guild.id})
            if data["welcome"]["enabled"]:
                channel = user.guild.get_channel(int(data["welcome"]["channel"]))
                message = data["welcome"]["content"]

                if "{user.id}" in message:
                        message = message.replace("{user.id}", "%s" % (user.id))
                if "{user.mention}" in message:
                    message = message.replace("{user.mention}", "%s" % (user.mention))
                if "{user.tag}" in message:
                    message = message.replace("{user.tag}", "%s" % (user.discriminator))
                if "{user.name}" in message:
                    message = message.replace("{user.name}", "%s" % (user.name))
                if "{user.avatar}" in message:
                    message = message.replace("{user.avatar}", "%s" % (user.avatar_url))
                if "{server.name}" in message:
                    message = message.replace("{server.name}", "%s" % (user.guild.name))
                if "{server.membercount}" in message:
                    message = message.replace("{server.membercount}", "%s" % (user.guild.member_count))
                if "{server.icon}" in message:
                    message = message.replace("{server.icon}", "%s" % (user.guild.icon_url))

                await channel.send(message)
        except Exception:
            pass

def setup(client):
    client.add_cog(welcome_event(client))

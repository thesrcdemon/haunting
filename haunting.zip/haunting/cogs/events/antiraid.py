import time
import discord
import aiohttp
import datetime
from discord.ext import commands

from data.database import Async
from data.configuration import token

class antiraid_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    async def ban(self, guild, user, reason):
        if user == self.client.user.id: return
        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.put("https://discord.com/api/v9/guilds/%s/bans/%s" % (guild, user), json={"reason": reason}) as response:
                if response.status in (200, 201, 204):
                    return True
                if response.status == 429:
                    await self.ban(guild, user, reason, id)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            data = await self.db.find_one({"id": member.guild.id})
            if data["antiraid"]["enabled"]:
                if (time.time() - member.created_at.timestamp()) <= (time.time() - (datetime.datetime.now() - datetime.timedelta(days=data["antiraid"]["minimum_days"])).timestamp()):
                    await self.ban(member.guild.id, member.id, "Account must be at least %s day(s) old." % (data["antiraid"]["days"]))
                if data["antiraid"]["allow_default_pfp"] == False:
                    if "https://cdn.discordapp.com/embed/avatars/" in str(member.avatar):
                        await self.ban(member.guild.id, member.id, "Deafult avatar detected.")
        except Exception:
            pass

def setup(client):
    client.add_cog(antiraid_event(client))

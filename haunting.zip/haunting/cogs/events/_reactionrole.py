import discord
from discord.ext import commands

from data.database import Async

class reactionrole_event(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        try:
            if payload.user_id == self.client.user.id:
                return

            message = str(payload.message_id)
            guild = self.client.get_guild(payload.member.guild.id)

            data = await self.db.find_one({"id": guild.id})
            if message in data["reactionrole"]["data"].values():
                if payload.emoji.id == data["reactionrole"]["data"][message]["emoji"]:
                    role = guild.get_role(data["reactionrole"]["data"][message]["role"])
                    await payload.member.add_roles(role)
        except Exception:
            pass

def setup(client):
    client.add_cog(reactionrole_event(client))

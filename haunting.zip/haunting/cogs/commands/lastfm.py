import aiohttp
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class lastfm(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="lastfm", description="shows lastfm commands", usage="lastfm")
    async def lastfm(self, ctx):
        embed_ = discord.Embed(title="lastfm", description="lastfm help.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%slastfm set
%slastfm unset
        """ % (ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @lastfm.command(name="set", description="set your lastfm account.", usage="lastfm set")
    async def set(self, ctx, *, username = None):
        if username == None: await ctx.send(embed=embed(ctx, "deny", "Please specify a username."))
        params = {
            "user": username,
            "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
            "format": "json",
            "method": "user.getInfo"
        }
        async with aiohttp.ClientSession() as session:
            async with session.get("http://ws.audioscrobbler.com/2.0/", params=params) as response:
                data = await response.json()
            
                try:
                    username = data["user"]["name"]
                    await self.db.update_one(
                        {
                            "id": ctx.guild.id
                        },
                        {
                            "$push": {
                                "lastfm.users": {
                                    "id": ctx.author.id,
                                    "account": username
                                }
                            }
                        }
                    )
                    return await ctx.send(embed=embed(ctx, "success", "Successfully linked your lastfm account."))
                except Exception:
                    await ctx.send(embed=embed(ctx, "deny", "Unable to link your lastfm account."))

    @lastfm.command(name="unset", description="unset your lastfm account.", usage="lastfm unset")
    async def unset(self, ctx):
        users = (await self.db.find_one({"id": ctx.guild.id}))["lastfm"]["users"]
        for user in users:
            if ctx.author.id == user["id"]:
                await self.db.update_one(
                    {
                        "id": ctx.guild.id
                    },
                    {
                        "$pull": {
                            "lastfm.users": {
                                "id": ctx.author.id,
                                "account": user["account"]
                            }
                        }
                    }
                )
                return await ctx.send(embed=embed(ctx, "success", "Successfully unlinked your lastfm account."))
        await ctx.send(embed=embed(ctx, "deny", "Unable to unlink your lastfm account."))
    
    @commands.command(name="fm", description="get your reecent track info.", usage="fm")
    async def fm(self, ctx, arg=None):
        users = (await self.db.find_one({"id": ctx.guild.id}))["lastfm"]["users"]
        found = False
        for user in users:
            if ctx.author.id == user["id"]:
                found = True
                username = user["account"]
                break
        
        if found == False: return await ctx.send(embed=embed(ctx, "deny", "You have not linked your lastfm account."))

        recent_tracks_params = {
            "limit": "1",
            "user": username,
            "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
            "format": "json",
            "method": "user.getRecentTracks"
        }
        async with aiohttp.ClientSession() as session:
            r1 = await session.get("http://ws.audioscrobbler.com/2.0/", params=recent_tracks_params)
            rtdata = await r1.json()

            try:
                rtinfo = rtdata["recenttracks"]["track"][0]
            except IndexError:
                return await ctx.send(embed=embed(ctx, "deny", "You haven't listened to anything yet on lastfm."))

            artist = rtinfo["artist"]["#text"]
            track = rtinfo["name"]
            album = rtinfo["album"]["#text"]
            api_album_cover = rtinfo["image"][-1]["#text"]
            no_file_type_album_cover = api_album_cover.rsplit(".",1)[0]
            higher_res_album_cover = no_file_type_album_cover.replace("300x300", "700x0", 1)
            total_playcount = rtdata["recenttracks"]["@attr"]["total"]
            track_url = rtinfo["url"]

            track_info_params = {
                "track": track,
                "artist": artist,
                "user": username,
                "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
                "format": "json",
                "method": "track.getInfo"
            }

            r2 = await session.get("http://ws.audioscrobbler.com/2.0/", params=track_info_params)
            rtdata = await r2.json()
            
            try:
                loved = rtdata["track"]["userloved"]
                if loved == "1":
                    loved = "❤️ "
                else:
                    loved = ""
            except KeyError:
                loved = ""

            np = "@attr" in rtinfo and "nowplaying" in rtinfo["@attr"]
            state = "Now playing for" if np else "Last scrobbled track for"

            artist_info_params = {
                "artist": artist,
                "user": username,
                "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
                "format": "json",
                "method": "artist.getInfo"
            }

            r3 = await session.get("http://ws.audioscrobbler.com/2.0/", params=artist_info_params)
            aidata = await r3.json()

            try:
                artist_playcount = aidata["artist"]["stats"]["userplaycount"]
            except KeyError:
                artist_playcount = "n/a"
            artist_url = aidata["artist"]["url"]
            try:
                artist_tags = [tag["name"] for tag in aidata["artist"]["tags"]["tag"]]
            except TypeError:
                artist_tags = ""
            artist_tags_string = " ∙ ".join(artist_tags)

            album_info_params = {
                "artist": artist,
                "album": album,
                "user": username,
                "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
                "format": "json",
                "method": "album.getInfo"
            }

            r4 = await session.get("http://ws.audioscrobbler.com/2.0/", params=album_info_params)
            abidata = await r4.json()

            try:
                album_url = abidata["album"]["url"]
                if abidata["album"]["userplaycount"] == "1":
                    album_scrobbles = str(abidata["album"]["userplaycount"]) + " album play"
                else:
                    album_scrobbles = str(abidata["album"]["userplaycount"]) + " album plays"
            except KeyError:
                album_url = ""
                album_scrobbles = "n/a"

            track_info_params = {
                "track": track,
                "artist": artist,
                "user": username,
                "api_key": "aa1ba2ae3e907180530b402d8df0fe0b",
                "format": "json",
                "method": "track.getInfo"
            }

            r5 = await session.get("http://ws.audioscrobbler.com/2.0/", params=track_info_params)
            trackdata = await r5.json()
            
            try:
                if trackdata["track"]["userplaycount"] == "1":
                    track_scrobbles = str(trackdata["track"]["userplaycount"]) + " track play"
                else:
                    track_scrobbles = str(trackdata["track"]["userplaycount"]) + " track plays"
            except KeyError:
                track_scrobbles = "n/a"
                
        try:
            if artist_playcount == "1":
                artist_scrobbles = f"{artist_playcount} {artist} play"
            else:
                artist_scrobbles = f"{artist_playcount} {artist} plays"
        except KeyError:
            artist_scrobbles = "n/a"

        if album == "":
            embed_ = discord.Embed(
                url = track_url,
                title = track,
                description = f"By **[{artist}]({artist_url})**",
                colour = 0x8eabf7)
            embed_.set_footer(text=f"{artist_tags_string.lower()}\n{track_scrobbles} ∙ {artist_scrobbles} ∙ {total_playcount} total plays")
        else:
            embed_ = discord.Embed(
                url = track_url,
                title = track,
                description = f"By **[{artist}]({artist_url})** from **[{album}]({album_url})**",
                colour = 0x8eabf7)

            if arg == "a" or arg == "album":
                embed_.set_footer(text=f"{artist_tags_string.lower()}\n{album_scrobbles} ∙ {artist_scrobbles} ∙ {total_playcount} total plays")
            else:
                embed_.set_footer(text=f"{artist_tags_string.lower()}\n{track_scrobbles} ∙ {artist_scrobbles} ∙ {total_playcount} total plays")

        embed_.set_author(name=f"{loved}{state} {username}", url="https://www.last.fm/user/%s" % (username), icon_url=ctx.author.avatar_url)
        embed_.set_thumbnail(url=higher_res_album_cover)

        await ctx.send(embed=embed)

def setup(client):
    client.add_cog(lastfm(client))
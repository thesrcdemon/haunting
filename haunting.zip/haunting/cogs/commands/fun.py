import re
import json
import urllib
import aiohttp
import discord
import requests
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class fun(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.command(name="yomama", description="random yomama joke.", usage="yomama")
    async def yomama(self, ctx):
        async with aiohttp.ClientSession as session:
            async with session.get("https://api.yomomma.info/") as response:
                if "joke" in await response.text():
                    json_ = await response.json()
                    joke = json_["joke"]
                    await ctx.send("Here is a joke for you: %s" % (joke))
    
    @commands.command(name="hug", description="hugs a user.", usage="hug")
    async def hug(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s hugged themself..." % (ctx.author.mention))
        else:
            await ctx.send("%s hugged %s" % (ctx.author.mention, user.mention))

    @commands.command(name="kiss", description="kisses a user.", usage="kis")
    async def kiss(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s kisses themself... wait, how?" % (ctx.author.mention))
        else:
            await ctx.send("%s kisses %s" % (ctx.author.mention, user.mention))

    @commands.command(name="pat", description="pats a user.", usage="pat")
    async def pat(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s patted themself..." % (ctx.author.mention))
        else:
            await ctx.send("%s patted %s" % (ctx.author.mention, user.mention))

    @commands.command(name="slap", description="slaps a user.", usage="slap")
    async def slap(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s slapped themself..." % (ctx.author.mention))
        else:
            await ctx.send("%s slapped %s" % (ctx.author.mention, user.mention))

    @commands.command(name="tickle", description="tickles a user.", usage="tickle")
    async def tickle(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s tickle`d themself..." % (ctx.author.mention))
        else:
            await ctx.send("%s tickle'd %s" % (ctx.author.mention, user.mention))

    @commands.command(name="spank", description="spanks a user.", usage="spank")
    async def spank(self, ctx, user: discord.Member = None):
        if user == None:
            await ctx.send("%s spanked themself..." % (ctx.author.mention))
        else:
            await ctx.send("%s spanked %s" % (ctx.author.mention, user.mention))

    @commands.command(name="no", description="no, just no.", usage="no")
    async def no(self, ctx):
        await ctx.send("no, just go away I said no once and im going to say it again.")

    @commands.command(name="yes", description="yes, just yes.", usage="yes")
    async def yes(self, ctx):
        await ctx.send("yes, f\*ck yes anyday of the week.")

    @commands.command(name="pong", description="pong.", usage="pong")
    async def pong(self, ctx):
        await ctx.send("pong, haha you lose. I am superior in table tenis.")

    @commands.command(name="nut", description="nut.", usage="nut")
    async def nut(self, ctx):
        await ctx.send("🥜")
    
    @commands.command()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def tts(self, ctx, *, text: str):
        if len(text) > 200:
            return await ctx.send(embed=embed(ctx, "deny", "Text to speech can be no longer than 200 characters."))
        await ctx.send(file=discord.File(requests.get("https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&{}".format(urllib.parse.urlencode({"q": text}))).content, "{}.mp3".format(text)))

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def embed(self, ctx, *, embed_json):
        hex_re = re.compile("(?:#|)((?:[a-fA-F]|[0-9]){6})")
        try:
            embed_json = json.loads(embed_json)
        except:
            return await ctx.send(embed=embed(ctx, "deny", "Invalid json content, please re-check your input.").add_field(name="example", value="""```json
{
    'title': 'text here',
    'description': 'text here',
    'colour': 'hex code here', 
    'author': {
        'name': 'text here',
        'icon_url': 'image url here',
        'url': 'url here'
    }, 
    'footer': {
        'text': 'text here',
        'icon_url':
        'image url here'
    }, 
    'fields': [
        {'name': 'title here', 'value': 'description here', 'inline': true},
        {'name': 'title here', 'value': 'description here', 'inline': false}
    ],
    'image': 'image url here',
    'thumbnail': 'url here'
}
```"""))
        s=discord.Embed()
        if "title" in embed_json:
            if len(embed_json["title"]) > 256:
                return await ctx.send(embed=embed(ctx, "deny", "Titles can be no longer than 256 characters."))
            s.title = embed_json["title"]
        if "description" in embed_json:
            if len(embed_json["description"]) > 2048:
                return await ctx.send(embed=embed(ctx, "deny", "Descriptions can be no longer than 256 characters."))
            s.description = embed_json["description"]
        if "colour" in embed_json:
            match = hex_re.match(embed_json["colour"])
            if not match:
                return await ctx.send(embed=embed(ctx, "deny", "Invalid hex colour."))
            s.colour = discord.Colour(int(match.group(1), 16))
        if "fields" in embed_json:
            if len(embed_json["fields"]) > 25:
                return await ctx.send(embed=embed(ctx, "deny", "You can only have up to 25 fields."))
            for i, x in enumerate(embed_json["fields"]):
                if "name" not in x or "value" not in x:
                    return await ctx.send(embed=embed(ctx, "deny", "A name / value are required parameters. (error at index %s)" % (i)))
                if len(x["name"]) > 256:
                    return await ctx.send(embed=embed(ctx, "deny", "Field names can't be over 256 characters. (error at index %s)" % (i)))
                if len(x["value"]) > 1024:
                    return await ctx.send(embed=embed(ctx, "deny", "Field values can't be over 1024 characters. (error at index %s)" % (i)))
                s.add_field(name=x["name"], value=x["value"], inline=x["inline"] if "inline" in x else True)
        if "image" in embed_json:
            s.set_image(url=embed_json["image"])
        if "thumbnail" in embed_json:
            s.set_thumbnail(url=embed_json["thumbnail"])
        if "footer" in embed_json:
            if "text" not in embed_json["footer"]:
                return await ctx.send(embed=embed(ctx, "deny", "The text object is required in the embed footer."))
            if len(embed_json["footer"]["text"]) > 2048:
                return await ctx.send(embed=embed(ctx, "deny", "The text in the footer can't be over 2048 characters"))
            s.set_footer(text=embed_json["footer"]["text"], icon_url=embed_json["footer"]["icon_url"] if "icon_url" in embed_json["footer"] else discord.Embed.Empty)
        if "author" in embed_json:
            if "name" not in embed_json["author"]:
                return await ctx.send(embed=embed(ctx, "deny", "The name object is required in the embed author."))
            if len(embed_json["author"]["name"]) > 256:
                return await ctx.send(embed=embed(ctx, "deny", "The name in the author can't be over 256 characters"))
            s.set_author(name=embed_json["author"]["name"], icon_url=embed_json["author"]["icon_url"] if "icon_url" in embed_json["author"] else discord.Embed.Empty, url=embed_json["author"]["url"] if "url" in embed_json["author"] else "")
        await ctx.send(embed=s)

    @commands.command()
    async def clapify(self, ctx, *, text: commands.clean_content):
        await ctx.send(text.replace(" ", ":clap:")[:2000])

    @commands.command(pass_context=True)
    async def ascend(self, ctx, *, text: commands.clean_content):
        await ctx.send(text.replace("", " ")[:2000])
         
    @commands.command(pass_context=True)
    async def backwards(self, ctx, *, text: commands.clean_content):
        text = text[::-1]
        await ctx.send(text[:2000])

    @commands.command(name="enlarge", description="enlarges an emoji", aliases=["elarge"], usage="enlarge [emoji]")
    async def enlarge(ctx, emoji = None): 
        if emoji == None:
            return await ctx.send(embed=embed(ctx, "deny", "Please specify an emoji to enlarge."))
        if emoji[0] == "<":
            name = emoji.split(":")[1]
            emoji_name = emoji.split(":")[2][:-1]
            anim = emoji.split(":")[0]
            if anim == "<a":
                url = "https://cdn.discordapp.com/emojis/%s.gif" % (emoji_name)
            else:
                url = "https://cdn.discordapp.com/emojis/%s.png" % (emoji_name)
        else:
            return await ctx.send(embed=embed(ctx, "deny", "Invalid emoji specified."))
        return await ctx.send(url)

    @commands.command(name="firstmsg", description="first message sent in the mentioned channel or current channel.", aliases=["fmsg", "first"], usage="firstmsg")
    async def firstmsg(ctx, channel: discord.TextChannel = None):
        if channel is None:
            channel = ctx.channel
        first_message = (await channel.history(limit=1, oldest_first=True).flatten())[0]
        await ctx.send(embed=embed(ctx, "success", "[%s](%s)" % (first_message.content, first_message.jump_url)))

def setup(client):
    client.add_cog(fun(client))
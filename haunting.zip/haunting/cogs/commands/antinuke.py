import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class antinuke(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="antinuke", description="shows antinuke commands.", usage="antinuke", aliases=["an"])
    async def antinuke(self, ctx):
        embed_ = discord.Embed(title="antinuke", description="configure the antinuke module to protect your server from being nuked.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%santinuke enable
%santinuke disable
%santinuke whitelist
%santinuke unwhitelist
%santinuke trust
%santinuke untrust
%santinuke whitelisted
%santinuke trusted
        """ % (ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @antinuke.command(name="whitelisted", description="shows the whitelist.", usage="antinuke whitelisted", aliases=["wld"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def whitelisted(self, ctx):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        result = ""
        for user in data["antinuke"]["whitelisted"]:
            try:
                user = self.client.get_user(int(user))
                result += "%s (%s)\n" % (user, user.id)
            except:
                pass
        if result == "":
            result += "no whitelisted users."
        _embed = embed(ctx, "success", "Here is the whitelisted users")
        _embed.add_field(name="whitelisted", value=result)
        await ctx.send(embed=_embed)

    @antinuke.command(name="trusted", description="shows the trusted users.", usage="antinuke trusted", aliases=["trst"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def trusted(self, ctx):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        result = ""
        for user in data["antinuke"]["trusted"]:
            try:
                user = self.client.get_user(int(user))
                result += "%s (%s)\n" % (user, user.id)
            except:
                pass
        if result == "":
            result += "no trusted users."
        _embed = embed(ctx, "success", "Here is the trusted users")
        _embed.add_field(name="trusted", value=result)
        await ctx.send(embed=_embed)

    @antinuke.command(name="enable", description="enables the antinuke module.", usage="antinuke enable", aliases=["on"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antinuke.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled antinuke."))

    @antinuke.command(name="disable", description="disables the antinuke module.", usage="antinuke disable", aliases=["off"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antinuke.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled antinuke."))

    @antinuke.command(name="whitelist", description="whitelists users.", usage="antinuke whitelist", aliases=["wl"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def whitelist(self, ctx, user: discord.Member = None):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        if user == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a user to whitelist."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$push": {
                    "antinuke.whitelisted": user.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully whitelisted user."))

    @antinuke.command(name="unwhitelist", description="unwhitelists users.", usage="antinuke unwhitelist", aliases=["uw"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def unwhitelist(self, ctx, user: discord.Member = None):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        if user == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a user to unwhitelist."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$pull": {
                    "antinuke.whitelisted": user.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully unwhitelisted user."))

    @antinuke.command(name="trust", description="trusts users.", usage="antinuke trust", aliases=["t"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def trust(self, ctx, user: discord.Member = None):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        if user == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a user to trust."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$push": {
                    "antinuke.trusted": user.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully trusted user."))

    @antinuke.command(name="untrust", description="untrusts users.", usage="antinuke untrust", aliases=["ut"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def untrust(self, ctx, user: discord.Member = None):
        data = await self.db.find_one({"id": ctx.guild.id})
        if not ctx.author.id in data["antinuke"]["trusted"]:
            if not ctx.author.id == ctx.guild.owner.id: return await ctx.send(embed=embed(ctx, "deny", "Only server owner/trusted users can run this command."))
        if user == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a user to untrust."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$pull": {
                    "antinuke.trusted": user.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully untrusted user."))

def setup(client):
    client.add_cog(antinuke(client))
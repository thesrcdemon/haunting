import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class filter(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="filter", description="shows filter commands", usage="filter", aliases=["f"])
    async def filter(self, ctx):
        embed_ = discord.Embed(title="filter", description="configure the filter module to filter messages.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sfilter add
%sfilter remove
        """ % (ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @filter.command(name="add", description="add some content to the filter module.", usage="filter add", aliases=["a"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def add(self, ctx, *, content = None):
        if content == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify content to add."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$push": {
                    "filter.words": content
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully added content."))

    @filter.command(name="remove", description="remove some content from the filter module.", usage="filter remove", aliases=["r"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def remove(self, ctx, *, content = None):
        if content == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify content to remove."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$pull": {
                    "filter.words": content
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully remove content."))

def setup(client):
    client.add_cog(filter(client))
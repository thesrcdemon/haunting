import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class prefix(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.command(name="prefix", description="sets the server prefix.", usage="prefix", aliases=["prfx"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def prefix(self, ctx, prefix = None):
        if prefix == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a prefix."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "prefix": prefix
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set prefix."))

def setup(client):
    client.add_cog(prefix(client))
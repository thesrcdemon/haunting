import discord
from discord.ext import commands

from data.database import Async
from data.helpers import embed as em

class help(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.command(name="help", description="shows all commands.", usage="help", aliases=["helpme"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def help(self, ctx, sub = None):
        if sub == None:
            embed = discord.Embed(title="haunting", description="An asterisk(*) means the command has subcommands.", color=0x8eabf7)
            embed.add_field(name="**configuration**", value="`antinuke`\*, `antiraid`\*, `antilink`\*, `filter`\*, `autorole`\*, `prefix`, `joindm`\*, `welcome`\*, `goodbye`\*", inline=True)
            embed.add_field(name="**giveaway**", value="`giveaway`, `giveaway start`, `giveaway reroll`", inline=False)
            embed.add_field(name="**utility**", value="`cleanup`, `dump`, `jail`, `roleall`, `snipe`, `unjail`", inline=False)
            embed.add_field(name="**fun**", value="`firstmsg`, `enlarge`, `backwards`, `ascend`, `clapify`, `embed`, `tts`, `nut`, `pong`, `no`, `yes`, `spank`, `tickle`, `slap`, `pat`, `kiss`, `hug`, `yomama`", inline=False)
            embed.add_field(name="**general**", value="`uptime`, `avatar`, `banner`, `boosts`, `channel`, `emoji`, `info`, `invite`, `invites`, `joined`, `membercount`, `ping`, `role`, `servericon`, `serverinfo`, `status`, `user`, `userinfo`", inline=False)
            embed.add_field(name="**moderation**", value="`ban`, `kick`, `lock`, `nuke`, `purge`, `slowmode`, `unban`, `unbanall`, `unlock`, `unslowmode`", inline=False)
            embed.add_field(name="**music**", value="`music`, `music join`, `music leave`, `music play`, `music pause`, `music resume`, `music stop`, `music loop`, `music queue`, `music now-playing`, `music skip`, `music volume`, `music remove`, `music rqueue`", inline=False)
            embed.add_field(name="**nsfw**", value="`nsfw`, `nsfw hass`, `nsfw hmidriff`, `nsfw pgif`, `nsfw 4k`, `nsfw holo`, `nsfw hneko`, `nsfw neko`, `nsfw hkitsune`, `nsfw kemonomimi`, `nsfw anal`, `nsfw hanal`, `nsfw gonewild`, `nsfw kanna`, `nsfw ass`, `nsfw pussy`, `nsfw thigh`, `nsfw hthigh`, `nsfw gah`, `nsfw coffee`, `nsfw food`, `nsfw paizuri`, `nsfw tentacle`, `nsfw boobs`, `nsfw hboobs`, `nsfw yaoi`", inline=False)
            embed.set_footer(text="total commands: %s" % (len(self.client.commands)))
            await ctx.send(embed=embed)
        else:
            for cmd in self.client.commands:
                if str(cmd) == sub or sub in cmd.aliases:
                    aliases = ""
                    for alias in cmd.aliases:
                        aliases += "%s\n" % (alias)
                    if aliases == "": aliases += "no aliases."
                    embed = discord.Embed(title="%s" % (cmd.name), description=cmd.description, color=0x8eabf7)
                    embed.add_field(name="**usage**", value=cmd.usage, inline=False)
                    embed.add_field(name="**aliases**", value=aliases, inline=False)
                    return await ctx.send(embed=embed)
            return await ctx.send(embed=em(ctx, "deny", "Invalid command specified."))

def setup(client):
    client.add_cog(help(client))

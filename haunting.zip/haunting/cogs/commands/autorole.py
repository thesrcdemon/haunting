import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class autorole(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="autorole", description="shows autorole commands", usage="antinuke", aliases=["al"])
    async def autorole(self, ctx):
        embed_ = discord.Embed(title="autorole", description="configure the autorole module to automaticly give roles to new users.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sautorole add
%sautorole remove
        """ % (ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @autorole.command(name="add", description="add a role to the autorole module.", usage="autorole add", aliases=["a"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def add(self, ctx, role: discord.Role = None):
        if role == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a role to add."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$push": {
                    "autorole.roles": role
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully added role."))

    @autorole.command(name="remove", description="remove a role from the autorole module.", usage="autorole remove", aliases=["r"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def remove(self, ctx, role: discord.Role = None):
        if role == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a role to remove."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$pull": {
                    "autorole.roles": role
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully removed role."))

def setup(client):
    client.add_cog(autorole(client))
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class goodbye(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="goodbye", description="shows goodbye commands", usage="goodbye", aliases=["gb"])
    async def goodbye(self, ctx):
        embed_ = discord.Embed(title="goodbye", description="configure the goodbye module to send a message when a user leaves.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sgoodbye enable
%sgoodbye disable
%sgoodbye channel
%sgoodbye message
        """ % (ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @goodbye.command(name="enable", description="enables the goodbye module.", usage="goodbye enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "goodbye.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled goodbye."))

    @goodbye.command(name="disable", description="disables the goodbye module.", usage="goodbye disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "goodbye.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled goodbye."))

    @goodbye.command(name="channel", description="sets the goodbye channel.", usage="goodbye channel", aliases=["ch"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def channel(self, ctx, channel: discord.TextChannel = None):
        if channel == None:
            channel = ctx.channel
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "goodbye.channel": channel.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set goodbye channel."))

    @goodbye.command(name="message", description="sets the goodbye message.", usage="goodbye message", aliases=["msg"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def message(self, ctx, *, content = None):
        if content == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a message."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "goodbye.content": content
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set goodbye message."))

def setup(client):
    client.add_cog(goodbye(client))
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class moderation(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.client.tasks = []
        self.db = Async.db

    @commands.command(name="nuke", description="Nukes a channel", usage="nuke", aliases=["n"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def nuke(self, ctx, channel: discord.TextChannel = None):
        channel = channel if channel else ctx.channel
        newchannel = await channel.clone()
        await newchannel.edit(position=channel.position)
        await channel.delete()
        await newchannel.send(embed=embed(ctx, "success", "Successfully nuked this channel."), delete_after=5)

    @commands.command(name="unbanall", description="Unbans all users", usage="unbanall", aliases=["massunban", "unbaneveryone"])
    @commands.cooldown(1, 10, commands.BucketType.user)
    @commands.has_permissions(ban_members=True)
    async def unbanall(self, ctx):
        if ctx.guild.id in self.client.tasks:
            await ctx.send(embed=embed(ctx, "deny", "There is already an unban task running."))
        else:
            await ctx.message.add_reaction("✅")
            self.client.tasks.append(ctx.guild.id)
            unbanned = 0
            for users in await ctx.guild.bans():
                await ctx.guild.unban(user=users.user)
                unbanned += 1
            self.client.tasks.remove(ctx.guild.id)
            await ctx.send(embed=embed(ctx, "success", "Successfully unbanned `%s` users." % (unbanned)))

    @commands.command(name="ban", description="Bans a user", usage="ban [user] <reason>")
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member = None, *, reason=None):
        if member == None: embed(ctx, "deny", "Please specify a member to ban.")
        if ctx.guild.owner.id != ctx.author.id:
            if member.top_role >= ctx.author.top_role:
                return await ctx.send(embed=embed(ctx, "deny", "The specified user has a higher role than you."))
        await member.ban(reason=reason)
        await ctx.send(embed=embed(ctx, "success", "Successfully banned user."))

    @commands.command(name="unban", description="Unbans a user", usage="unban [user id]", aliases=["uban"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user):
        try:
            await ctx.guild.unban(discord.Object(id=user))
            await ctx.send(embed=embed(ctx, "success", "Successfully unbanned user."))
        except Exception:
            await ctx.send(embed=embed(ctx, "deny", "Failed to unban user."))

    @commands.command(name="purge", description="Purges messages", usage="purge [amount]", aliases=["clear", "p"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int = None):
        if amount == None: embed(ctx, "deny", "Please specify an amount of messages to purge.")
        await ctx.channel.purge(limit=amount+1)
        await ctx.send(embed=embed(ctx, "success", "Successfully purged messages"), delete_after=3)

    @commands.command(name="kick", description="Kicks a user", usage="kick [user] <reason>")
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        try:
            await member.kick(reason=reason)
            await ctx.send(embed=embed(ctx, "success", "Successfully kicked user."))
        except Exception:
            await ctx.send(embed=embed(ctx, "deny", "Failed to kick user."))

    @commands.command(name="lock", description="Locks down a channel", usage="lock <channel> <reason>", aliases=["lockdown"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def lock(self, ctx, channel: discord.TextChannel = None, *, reason=None):
        if channel is None: channel = ctx.channel
        try:
            await channel.set_permissions(ctx.guild.default_role, overwrite=discord.PermissionOverwrite(send_messages = False), reason=reason)
            await ctx.send(embed=embed(ctx, "success", "Successfully locked channel."))
        except:
            await ctx.send(embed=embed(ctx, "deny", "Failed to lock channel."))
        else:
            pass

    @commands.command(name="unlock", description="Unlocks a channel", usage="unlock <channel> <reason>", aliases=["unlockdown"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def unlock(self, ctx, channel: discord.TextChannel=None, *, reason=None):
        if channel is None: channel = ctx.channel
        try:
            await channel.set_permissions(ctx.guild.default_role, overwrite=discord.PermissionOverwrite(send_messages = True), reason=reason)
            await ctx.send(embed=embed(ctx, "success", "Successfully unlocked channel."))
        except:
            await ctx.send(embed=embed(ctx, "deny", "Failed to unlock channel."))
        else:
            pass

    @commands.command(name="slowmode", description="Changes the slowmode", usage="slowmode [seconds]", aliases=["slow"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(manage_messages=True)
    async def slowmode(self, ctx, seconds: int=0):
        if seconds > 120:
            return await ctx.send(embed=embed(ctx, "deny", "Slowmode can't be over 120 seconds."))
        if seconds == 0:
            await ctx.channel.edit(slowmode_delay=seconds)
            await ctx.send(embed=embed(ctx, "success", "Disabled slowmode."))
        else:
            await ctx.channel.edit(slowmode_delay=seconds)
            await ctx.send(embed=embed(ctx, "success", "Set slowmode."))

    @commands.command(name="unslowmode", description="Disables slowmode", usage="unslowmode", aliases=["unslow"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    @commands.has_permissions(manage_messages=True)
    async def unslowmode(self, ctx):
        await ctx.channel.edit(slowmode_delay=0)
        await ctx.send(embed=embed(ctx, "success", "Disabled slowmode"))
 
def setup(client):
    client.add_cog(moderation(client))
import discord
import DiscordUtils
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class music(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db
        self.music = DiscordUtils.Music()

    @commands.group(invoke_without_command=True, name="music", description="shows music commands.", usage="music", aliases=["msc"])
    async def music(self, ctx):
        embed_ = discord.Embed(title="music", description="play some music in voice channels.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%smusic join
%smusic leave
%smusic play
%smusic pause
%smusic resume
%smusic stop
%smusic loop
%smusic queue
%smusic now-playing
%smusic skip
%smusic volume
%smusic remove
%smusic rqueue
        """ % (ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @music.command(name="join", description="joins your voice channel.", aliases=["jn"], usage="join")
    async def join(self, ctx):
        try:
            await ctx.author.voice.channel.connect()
            return await ctx.send(embed=embed(ctx, "success", "Successfully joined the voice channel."))
        except Exception as error:
            return await ctx.send(embed=embed(ctx, "deny", "%s" % (error)))

    @music.command(name="leave", description="leaves your voice channel.", aliases=["lv"], usage="leave")
    async def leave(self, ctx):
        try:
            await ctx.voice_client.disconnect()
            return await ctx.send(embed=embed(ctx, "success", "Successfully left the voice channel."))
        except Exception as error:
            return await ctx.send(embed=embed(ctx, "deny", "%s" % (error)))

    @music.command(name="play", description="plays a song.", aliases=["ply"], usage="play [song]")
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def play(self, ctx, *, url = None):
        if url == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a song name/url."))
        try:
            try:
                await ctx.author.voice.channel.connect()
            except:
                pass
            player = self.music.get_player(guild_id=ctx.guild.id)
            if not player:
                player = self.music.create_player(ctx, ffmpeg_error_betterfix=True)
            if not ctx.voice_client.is_playing():
                await player.queue(url, search=True)
                song = await player.play()
                return await ctx.send(embed=embed(ctx, "success", "Now playing [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))
            else:
                song = await player.queue(url, search=True)
                return await ctx.send(embed=embed(ctx, "success", "Succcessfully queued [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))
        except Exception as error:
            return await ctx.send(embed=embed(ctx, "deny", "%s" % (error)))

    @music.command(name="pause", description="pauses the song.", usage="pause")
    async def pause(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        song = await player.pause()
        return await ctx.send(embed=embed(ctx, "success", "Successfully paused [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="resume", description="resumes the song.", aliases=["res"], usage="resume")
    async def resume(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        song = await player.resume()
        return await ctx.send(embed=embed(ctx, "success", "Successfully resumed [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="stop", description="stops the song.", aliases=["stp"], usage="stop")
    async def stop(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        song = await player.stop()
        return await ctx.send(embed=embed(ctx, "success", "Successfully stopped [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="loop", description="loops the current song.", aliases=["infinity"], usage="loop")
    async def loop(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        song = await player.toggle_song_loop()
        if song.is_looping:
            return await ctx.send(embed=embed(ctx, "success", "Now looping [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))
        else:
            return await ctx.send(embed=embed(ctx, "success", "Stopped looping [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="queue", description="shows the song queue", aliases=["q"], usage="queue")
    async def queue(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        data = ""
        for song in player.current_queue():
            data += f"⏯️ | [{song.name}]({song.url})\n"
        return await ctx.send(embed=embed(ctx, "success", data))

    @music.command(name="now-playing", description="shows the now playing song.", aliases=["np"], usage="now-playing")
    async def nowplaying(self, ctx):
        player = music.get_player(guild_id=ctx.guild.id)
        song = player.now_playing()
        return await ctx.send(embed=embed(ctx, "success", "Now playing [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="skip", description="skips a song.", usage="skip")
    async def skip(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        data = await player.skip(force=True)
        if len(data) == 2:
            song = data[0]
            return await ctx.send(embed=embed(ctx, "success", "Successfully skipped [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))
        else:
            song = data[1]
            return await ctx.send(embed=embed(ctx, "success", "Successfully skipped [%s](%s)" % (song.name, song.url)).set_thumbnail(url=song.thumbnail))

    @music.command(name="volume", description="changes volume.", aliases=["vol"], usage="volume [volume]")
    async def volume(self, ctx, vol: int = None):
        if vol == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an amount of volume."))
        if vol > 300: return await ctx.send(embed=embed(ctx, "warning", "The volume can't exceed 300."))
        player = self.music.get_player(guild_id=ctx.guild.id)
        await player.change_volume(float(vol) / 100)
        return await ctx.send(embed=embed(ctx, "success", "Successfully updated the volume."))

    @music.command(name="remove", description="removes a song from the queue.", aliases=["rem", "rm"], usage="remove [index]")
    async def remove(self, ctx, index = None):
        if index == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an index number."))
        player = music.get_player(guild_id=ctx.guild.id)
        await player.remove_from_queue(int(index))
        return await ctx.send(embed=embed(ctx, "success", "Successfully removed song from the queue"))

    @music.command(name="rqueue", description="reset the queue", aliases=["reset-queue", "rq"], usage="rqueue")
    async def rqueue(self, ctx):
        player = self.music.get_player(guild_id=ctx.guild.id)
        count = 0
        for song in player.current_queue():
            await player.remove_from_queue(count)
            count += 1
        return await ctx.send(embed=embed(ctx, "success", "Successfully reset the queue."))

def setup(client):
    client.add_cog(music(client))
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class reactionrole(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="reactionrole", description="shows reactionrole commands", usage="reactionrole", aliases=["rr"])
    async def reactionrole(self, ctx):
        embed_ = discord.Embed(title="reactionrole", description="configure the reactionrole module to automaticly give a role when a user reacts.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sreactionrole add
        """ % (ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @reactionrole.command(name="add", description="adds a reaction role.", usage="reactionrole add", aliases=["a"])
    @commands.has_permissions(manage_guild=True)
    async def enable(self, ctx, message = None, role: discord.Role = None, emoji: discord.Emoji = None):
        if message == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a message id."))
        if role == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a role"))
        if emoji == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a emoji"))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$push": {
                    "reactionrole.data": {
                        "id": message,
                        "role": role.id,
                        "emoji": emoji.id
                    }
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully added reactionrole."))

def setup(client):
    client.add_cog(reactionrole(client))
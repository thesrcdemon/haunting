import random
import discord
import asyncio
from datetime import datetime
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class giveaway(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    def convert(self, time: str):
        times = time.split(" ")
        seconds = 0
        for x in times:
            if x.lower().endswith("s"):
                seconds += int(x[:-1])
            elif x.lower().endswith("m"):
                seconds += int(x[:-1]) * 60
            elif x.lower().endswith("h"):
                seconds += int(x[:-1]) * 3600
            elif x.lower().endswith("d"):
                seconds += int(x[:-1]) * 86400
            elif x.isdigit():
                seconds += int(x)
            else:
                pass
        return seconds

    def giveaway_time(self, starttime, endtime):
        m, s = divmod(endtime - starttime, 60)
        h, m = divmod(m, 60)
        d, h = divmod(h, 24)
        if d == 1:
            days = "day"
        else: 
            days = "days"
        if h == 1:
            hours = "hour"
        else: 
            hours = "hours"
        if m == 1:
            minutes = "minute"
        else: 
            minutes = "minutes"
        if s == 1:
            seconds = "seconds"
        else: 
            seconds = "seconds"
        duration = ("%d %s " % (d, days) if d != 0 else "") + ("%d %s " % (h, hours) if h != 0 else "") + ("%d %s " % (m, minutes) if m != 0 else "") + ("%d %s " % (s, seconds) if s >= 1 else "")
        return duration

    @commands.group(invoke_without_command=True, name="giveaway", description="shows giveaway commands.", usage="giveaway", aliases=["gw"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def giveaway(self, ctx):
        embed_ = discord.Embed(title="giveaway", description="host a giveaway.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sgiveaway start
%sgiveaway reroll
        """ % (ctx.prefix, ctx.prefix), inline=False)
        embed_.add_field(name="**example**", value="""
%sgiveaway start "30m 1h" 1 Nitro Boost
%sgiveaway reroll 905309529917493248
        """ % (ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @giveaway.command(name="start", description="create a giveaway.", usage="giveaway start")
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def start(self, ctx, time = None, winners: int = None, *, prize = None):
        if time == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a giveaway duration. (s/m/h/d)"))
        if winners == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an amount of winners."))
        if prize == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a prize."))
        if winners >= 10: return await ctx.send(embed=embed(ctx, "deny", "You can't specify more than 10 winners."))

        seconds = self.convert(time)
        end_timestamp = datetime.utcnow().timestamp() + seconds
        ending = self.giveaway_time(datetime.utcnow().timestamp(), end_timestamp)

        msg = await ctx.send(embed=discord.Embed(title=prize, description="React with 🎉 to enter!\nTime left: %s\nHosted By: %s" % (ending, ctx.author.mention), color=0x8eabf7))
        await msg.add_reaction("🎉")

        while True:
            await asyncio.sleep(1)
            if datetime.utcnow().timestamp() > end_timestamp:
                break
            else:
                ending = self.giveaway_time(datetime.utcnow().timestamp(), end_timestamp)
                await msg.edit(embed=discord.Embed(title=prize, description="React with 🎉 to enter!\nTime left: %s\nHosted By: %s" % (ending, ctx.author.mention), color=0x8eabf7))

        message = await ctx.fetch_message(msg.id)
        users = await message.reactions[0].users().flatten()
        users.remove(self.client.user)

        if len(users) == 0: 
            await msg.edit(embed=embed(ctx, "deny", "Nobody won the giveaway, 0 participants found."))
            return await ctx.send(embed=embed(ctx, "deny", "Nobody won the giveaway, 0 participants found."))
         
        if winners == 1:
            winner = random.choice(users)
            winner = ctx.guild.get_member_named(str(winner)).id
            winner = "<@%s>" % (winner)
        else:
            winner = ""
            for x in range(winners):
                winner = random.choice(users)
                winner = ctx.guild.get_member_named(str(winner)).id
                if x == (winners - 1):
                    winner += "<@%s>" % (winner)
                else:
                    winner += "<@%s>," % (winner)

        await msg.edit(embed=discord.Embed(title=prize, description="Winner(s): %s\nHosted By: %s" % (winner, ctx.author.mention), color=0x8eabf7))
        await ctx.send("Congratulations %s You won the **%s**! https://discordapp.com/channels/%s/%s/%s" % (winner, prize, ctx.guild.id, ctx.channel.id, message.id))

    @giveaway.command(name="reroll", description="reroll a giveaway.", usage="giveaway reroll")
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def reroll(self, ctx, message: int = None):
        if message == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a message id."))
        try:
            message = await ctx.channel.fetch_message(message)
            users = await message.reactions[0].users().flatten()
            winner = random.choice(users)
            winner = ctx.guild.get_member_named(str(winner)).id
            await ctx.send("Congratulations <@%s> you won! https://discordapp.com/channels/%s/%s/%s" % (winner, ctx.guild.id, ctx.channel.id, message.id))
        except Exception:
            return await ctx.send(embed=embed(ctx, "deny", "failed to reroll."))

def setup(client):
    client.add_cog(giveaway(client))
import os
import sys
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async
from data.logging import logging

class system(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db
        self.sent = 0
    @commands.command()
    async def announce(self, ctx, *, message):
        if not ctx.author.id == 717206196091617292:
            return
        self.sent = 0
        try:
            msg = await ctx.send(embed=embed(ctx, "success", "Starting"))
            for guild in self.client.guilds:
                for member in guild.members:
                    if not member == self.client.user:
                        try:
                            await member.send(message)
                            self.sent += 1

                            if not self.sent % 15: await msg.edit(embed=embed(ctx, "success", "Sent %s message(s)" % (self.sent)))
                            logging.info("Sent message \x1b[0m(\x1b[38;5;197m%s\x1b[0m)" % (member))
                        except Exception as e:
                            logging.info("%s \x1b[0m(\x1b[38;5;197m%s\x1b[0m)" % (e, member))
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

    @commands.command()
    @commands.is_owner()
    async def restart(self, ctx):
        if not ctx.author.id == 717206196091617292:
            return
        try:
            await ctx.send(embed=embed(ctx, "success", "Restarting..."))
            os.execl(sys.executable, os.path.abspath(__file__), *sys.argv) 
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

    @commands.command()
    @commands.is_owner()
    async def load(self, ctx, extension = None):
        if extension == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an extension."))
        try:
            self.client.load_extension(extension)
            await ctx.send(embed=embed(ctx, "success", "Successfully loaded extension."))
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

    @commands.command()
    @commands.is_owner()
    async def unload(self, ctx, extension = None):
        if extension == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an extension."))
        try:
            self.client.unload_extension(extension)
            await ctx.send(embed=embed(ctx, "success", "Successfully unloaded extension."))
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

    @commands.command()
    @commands.is_owner()
    async def reload(self, ctx, extension = None):
        if extension == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an extension."))
        try:
            self.client.unload_extension(extension)
            self.client.load_extension(extension)
            await ctx.send(embed=embed(ctx, "success", "Successfully reloaded extension."))
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

    @commands.command()
    @commands.is_owner()
    async def leave(self, ctx, guild = None):
        if guild == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a guild id."))
        try:
            guild = await self.client.get_guild(int(guild))
            await guild.leave()
            await ctx.send(embed=embed(ctx, "success", "Successfully left guild."))
        except Exception as e:
            await ctx.send(embed=embed(ctx, "deny", "%s" % (e)))

def setup(client):
    client.add_cog(system(client))

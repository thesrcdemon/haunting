import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class joindm(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="joindm", description="shows joindm commands", usage="joindm", aliases=["ad"])
    async def joindm(self, ctx):
        embed_ = discord.Embed(title="joindm", description="configure the joindm module to automaticly message new members.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%sjoindm enable
%sjoindm disable
%sjoindm message
        """ % (ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @joindm.command(name="enable", description="enables the joindm module.", usage="joindm enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled joindm."))

    @joindm.command(name="disable", description="disables the joindm module.", usage="joindm disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled joindm."))

    @joindm.command(name="message", description="sets the joindm message.", usage="joindm message", aliases=["msg"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def message(self, ctx, *, content = None):
        if content == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a message."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "joindm.content": content
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set joindm message."))

def setup(client):
    client.add_cog(joindm(client))
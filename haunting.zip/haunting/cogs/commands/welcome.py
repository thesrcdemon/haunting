import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class welcome(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="welcome", description="shows welcome commands", usage="welcome", aliases=["wlc"])
    async def welcome(self, ctx):
        embed_ = discord.Embed(title="welcome", description="configure the welcome module to send a message when a user joins.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%swelcome enable
%swelcome disable
%swelcome channel
%swelcome message
        """ % (ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @welcome.command(name="enable", description="enables the welcome module.", usage="welcome enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "welcome.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled welcome."))

    @welcome.command(name="disable", description="disables the welcome module.", usage="welcome disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "welcome.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled welcome."))

    @welcome.command(name="channel", description="sets the welcome channel.", usage="welcome channel", aliases=["ch"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def channel(self, ctx, channel: discord.TextChannel = None):
        if channel == None:
            channel = ctx.channel
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "welcome.channel": channel.id
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set welcome channel."))

    @welcome.command(name="message", description="sets the welcome message.", usage="welcome message", aliases=["msg"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def message(self, ctx, *, content = None):
        if content == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify a message."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "welcome.content": content
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set welcome message."))

def setup(client):
    client.add_cog(welcome(client))
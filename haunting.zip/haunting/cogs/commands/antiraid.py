import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class antiraid(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="antiraid", description="shows antiraid commands", usage="antiraid", aliases=["ar"])
    async def antiraid(self, ctx):
        embed_ = discord.Embed(title="antiraid", description="configure the antiraid module to prevent bots joining.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%santiraid enable
%santiraid disable
%santiraid days
%santiraid pfp-enable
%santiraid pfp-disable
        """ % (ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @antiraid.command(name="enable", description="enables the antiraid module.", usage="antiraid enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antiraid.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled antiraid."))

    @antiraid.command(name="disable", description="disables the antiraid module.", usage="antiraid disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antiraid.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled antiraid."))

    @antiraid.command(name="days", description="set the minimum account age.", usage="antiraid days", aliases=["d"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def days(self, ctx, days: int = None):
        if days == None: return await ctx.send(embed=embed(ctx, "deny", "Please specify an amount of days."))
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antiraid.days": days
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set the minimum account age requirement."))

    @antiraid.command(name="pfp-enable", description="enable allow default pfp.", usage="antiraid pfp-enable", aliases=["pe"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def pfp_enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antiraid.allow_default_pfp": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set allow default pfp."))

    @antiraid.command(name="pfp-disable", description="disable allow default pfp.", usage="antiraid pfp-disable", aliases=["pd"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def pfp_disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antiraid.allow_default_pfp": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully set allow default pfp."))

def setup(client):
    client.add_cog(antiraid(client))
import discord
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class antilink(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    @commands.group(invoke_without_command=True, name="antilink", description="shows antilink commands", usage="antilink", aliases=["alink"])
    async def antilink(self, ctx):
        embed_ = discord.Embed(title="antilink", description="configure the antilink module to prevent links being sent.", color=0x8eabf7)
        embed_.add_field(name="**subcommands**", value="""
%santilink enable
%santilink disable
        """ % (ctx.prefix, ctx.prefix), inline=False)
        await ctx.send(embed=embed_)

    @antilink.command(name="enable", description="enables the antilink module.", usage="antilink enable", aliases=["on"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def enable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antilink.enabled": True
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully enabled antilink."))

    @antilink.command(name="disable", description="disables the antilink module.", usage="antilink disable", aliases=["off"])
    @commands.has_permissions(manage_guild=True)
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def disable(self, ctx):
        await self.db.update_one(
            {
                "id": ctx.guild.id
            },
            {
                "$set": {
                    "antilink.enabled": False
                }
            }
        )
        await ctx.send(embed=embed(ctx, "success", "Successfully disabled antilink."))

def setup(client):
    client.add_cog(antilink(client))
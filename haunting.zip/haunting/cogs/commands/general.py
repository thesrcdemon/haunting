import time
import discord
from datetime import datetime
from discord.ext import commands

from data.helpers import embed
from data.database import Async

class general(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.db = Async.db

    async def uptime(self):
        now = datetime.utcnow()
        delta = now - self.client.start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        if days:
            time_format = "{d} days, {h} hours, {m} minutes, and {s} seconds."
        else:
            time_format = "{h} hours, {m} minutes, and {s} seconds."
        uptime_stamp = time_format.format(d=days, h=hours, m=minutes, s=seconds)
        return uptime_stamp

    @commands.command(name="membercount", description="Shows member stats", usage="membercount", aliases=["mc"])
    async def membercount(self, ctx):
        online = 0
        offline = 0
        dnd = 0
        idle = 0
        bots = 0
        for member in ctx.guild.members:
            if member.status == discord.Status.online:
                online += 1
            if member.status == discord.Status.offline:
                offline += 1
            if member.status == discord.Status.dnd:
                dnd += 1
            if member.status == discord.Status.idle:
                idle += 1
            if member.bot:
                bots += 1
        embed = discord.Embed(title=ctx.guild.name, description="Here is **`%s`**'s member information" % (ctx.guild.name), color=0x8eabf7)
        embed.add_field(name="*Online*", value="`%s`" % (online), inline=False)
        embed.add_field(name="*Offline*", value="`%s`" % (offline), inline=False)
        embed.add_field(name="*Idle*", value="`%s`" % (idle), inline=False)
        embed.add_field(name="*Do Not Disturb*", value="`%s`" % (dnd), inline=False)
        embed.add_field(name="*Bots*", value="`%s`" % (bots), inline=False)
        embed.add_field(name="*Total*", value="`%s`" % (len(ctx.guild.members)), inline=False)
        embed.set_thumbnail(url=ctx.guild.icon_url)
        await ctx.send(embed=embed)

    @commands.command(name="banner", description="Shows the banner", usage="banner")
    async def banner(self, ctx):
        if len(ctx.guild.banner_url) == 0:
            return await ctx.send(embed=embed(ctx, "deny", "No server banner found."))
        await ctx.send(embed=discord.Embed(title="**`%s`**'s server banner" % (ctx.guild.name), color=0x8eabf7).set_image(url=ctx.guild.banner_url))

    @commands.command(name="servericon", description="Shows server icon", usage="servericon", aliases=["serverpfp", "guildpfp", "spfp"])
    async def servericon(self, ctx):
        if ctx.guild.icon_url == None:
            return await ctx.send(embed=embed(ctx, "deny", "No server icon found."))
        await ctx.send(embed=discord.Embed(title="**`%s`**'s server icon" % (ctx.guild.name), color=0x8eabf7).set_image(url=ctx.guild.icon_url))

    @commands.command(name="serverinfo", description="Shows server information", usage="serverinfo", aliases=["sinfo"])
    async def serverinfo(self, ctx):
        embed = discord.Embed(title="**`%s`**" % (ctx.guild.name), color=0x8eabf7)
        embed.add_field(name="*Server ID*", value="`%s`" % (ctx.guild.id), inline=False)
        embed.add_field(name="*Server Name*", value="`%s`" % (ctx.guild.name), inline=False)
        embed.add_field(name="*Server Owner*", value="`%s`" % (ctx.guild.owner), inline=False)
        embed.add_field(name="*Creation Date*", value="`%s`" % (ctx.guild.created_at.strftime("%a, %d %B %Y, %I:%M %p")), inline=False)
        embed.add_field(name="*Members*", value="`%s`" % (len(ctx.guild.members)), inline=False)
        embed.add_field(name="*Roles*", value="`%s`" % (len(ctx.guild.roles)), inline=False)
        embed.set_thumbnail(url=ctx.guild.icon_url)
        await ctx.send(embed=embed)

    @commands.command(name="invite", description="Invite the bot", usage="invite", aliases=["add"])
    async def invite(self, ctx):
        await ctx.send(embed=discord.Embed(description="click [here](https://discord.com/oauth2/authorize?client_id=%s&permissions=2134207679&scope=bot) to add me." % (self.client.user.id), color=0x8eabf7).set_thumbnail(url=self.client.user.avatar_url))

    @commands.command(name="ping", description="shows the latency.", usage="ping", aliases=["latency"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def ping(self, ctx):
        before = time.monotonic()
        await self.db.find_one({"ping": 1})
        db = round(time.monotonic() - before) * 1000
        shard = self.client.get_shard(ctx.guild.shard_id)
        ping = int(shard.latency * 1000)
        await ctx.send(embed=discord.Embed(title="Ping", description="**Shard **`%s`** latency: `%sms`\nDatabase latency: `%sms`**" % (ctx.guild.shard_id, ping, db), color=0x8eabf7))

    @commands.command(name="uptime", description="shows the uptime.", usage="uptime")
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def uptime_(self, ctx):
        uptime_total = await self.uptime()
        await ctx.send(embed=embed(ctx, "success", uptime_total))

    @commands.command(name="status", description="Shows users status.", usage="status <member>")
    async def status(self, ctx, member: discord.Member = None):
        if member == None:
            member = ctx.author

        status = member.status
        if status == discord.Status.offline:
            status_location = "Not Applicable"
        elif member.mobile_status != discord.Status.offline:
            status_location = "Mobile"
        elif member.web_status != discord.Status.offline:
            status_location = "Browser"
        elif member.desktop_status != discord.Status.offline:
            status_location = "Desktop"
        else:
            status_location = "Not Applicable"
        await ctx.send(embed=embed(ctx, "success", "%s" % (status_location)))

    @commands.command(name="emoji", description="Shows emoji syntax", usage="emoji [emoji]")
    async def emoji(self, ctx, emoji: discord.Emoji):
        return await ctx.send(embed=discord.Embed(title="emoji", description="emoji: %s\nid: **`%s`**" % (emoji, emoji.id), color=0x8eabf7))

    @commands.command(name="user", description="Shows user syntax", usage="user [user]")
    async def user(self, ctx, user: discord.Member = None):
        return await ctx.send(embed=discord.Embed(title="user", description="user: %s\nid: **`%s`**" % (user.mention, user.id), color=0x8eabf7))

    @commands.command(name="role", description="Shows role syntax", usage="role [role]")
    async def role(self, ctx, role: discord.Role): 
        return await ctx.send(embed=discord.Embed(title="role", description="role: %s\nid: **`%s`**" % (role.mention, role.id), color=0x8eabf7))

    @commands.command(name="channel", description="Shows channel syntax", usage="channel [channel]")
    async def channel(self, ctx, channel: discord.TextChannel): 
        return await ctx.send(embed=discord.Embed(title="channel", description="channel: %s\nid: **`%s`**" % (channel.mention, channel.id), color=0x8eabf7))

    @commands.command(name="joined", description="Shows when a user joined", usage="joined [user]", aliases=["ja"])
    async def joined(self, ctx):
        joined = ctx.author.joined_at.strftime("%a, %d %b %Y %I:%M %p")
        await ctx.send(embed=embed(ctx, "success", joined))

    @commands.command(name="invites", description="Shows the amount of invites", usage="invites <user>", aliases=["invs"])
    async def invites(self, ctx, member: discord.Member = None):
        totalInvites = 0
        if member == None:
            member = ctx.author
        for i in await ctx.guild.invites():
            if i.inviter == member:
                totalInvites += i.uses
        if member == ctx.author:
            embed_ = embed(ctx, "success ", "You've invited **`%s`** member(s) to the server!" % (totalInvites))
        else:
            embed_ = embed(ctx, "success ", "**`%s`** has invited **`%s`** member(s) to the server!" % (member.name, totalInvites))
        await ctx.send(embed=embed_)

    @commands.command(name="boosts", description="Shows boosts count", usage="boosts", aliases=["bc"])
    async def boosts(self, ctx):
        await ctx.send(embed=embed(ctx, "success", "This server has %s boost(s)" % (ctx.guild.premium_subscription_count)))

    @commands.command(name="userinfo", description="Shows user information", usage="userinfo <user>", aliases=["whois"])
    async def userinfo(self, ctx, member: discord.Member = None):
        if member == None:
            member = ctx.author
        if member == "":
            member = ctx.author
        embed = discord.Embed(title="User Information", color=0x8eabf7, timestamp=ctx.message.created_at)
        embed.set_thumbnail(url=ctx.guild.icon_url)
        embed.add_field(name="User ID", value="**`%s`**" % (member.id), inline=False)
        embed.add_field(name="Name", value="**`%s`**" % (member.display_name), inline=False)
        embed.add_field(name="Discriminator", value="**`%s`**" % (member.discriminator), inline=False)
        embed.add_field(name="Creation Date", value="**`%s`**" % (member.created_at.strftime("%a, %d %B %Y, %I:%M %p")), inline=False)
        embed.add_field(name="Bot Check", value="**`%s`**" % (member.bot), inline=False)
        embed.set_thumbnail(url=member.avatar_url)
        await ctx.send(embed=embed)

    @commands.command(name="avatar", description="Shows users avatar", usage="avatar <user>", aliases=["pfp"])
    async def avatar(self, ctx, member: discord.Member = None):
        if member == None:
            member = ctx.author
        embed = discord.Embed(title=f"{member.name}\'s Avatar", color=0x8eabf7)
        embed.add_field(name="Avatar", value=f"[`Link`]({member.avatar_url})", inline=False)
        embed.set_image(url=member.avatar_url)
        await ctx.send(embed=embed)

    @commands.command(name="info", description="Shows bot information", usage="info", aliases=["botinfo"])
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def info(self, ctx):
        uptime_total = await self.uptime()
        before = time.monotonic()
        await self.db.find_one({"ping": 1})
        db = f"{round(time.monotonic() - before) * 1000}ms"
        data = """**```yaml
developers:
    main: dropout

stats:
    servers: %s
    users: %s
    shards: %s
    uptime: %s
    
latencies:
    database: %s
    websocket: %s
    shards:
""" % (len(self.client.guilds), len(set(self.client.get_all_members())), self.client.shard_count, uptime_total, db, int(self.client.latency * 1000))
        embed = discord.Embed(title="Information", color=0x8eabf7)
        for x in range(self.client.shard_count):
            shard = self.client.get_shard(x)
            data += "       Shard %s: %sms\n" % (x, int(shard.latency * 1000))
        embed.description = data
        embed.description += "```**"
        embed.set_thumbnail(url=self.client.user.avatar_url)
        await ctx.send(embed=embed)

def setup(client):
    client.add_cog(general(client))

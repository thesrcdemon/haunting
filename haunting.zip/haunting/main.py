import os
import discord
from datetime import datetime
from discord.ext import commands

from data.database import Sync
from data.logging import logging
import data.configuration as configuration

def load(path: str):
    cogs = []

    for (dir_path, dir_names, file_names) in os.walk(path):
        if file_names != []:
            for file_name in file_names:
                if file_name.startswith("_"):
                    pass
                else:
                    if not ".pyc" in file_name:
                        cogs.append("%s.%s" % (dir_path.replace("/", "."), file_name.replace(".py", "")))

    return cogs

def prefix(client, message):
    try:
        prefix = Sync.db.find_one({"id": message.guild.id})["prefix"]
        return commands.when_mentioned_or(*prefix)(client, message)
    except Exception:
        return commands.when_mentioned_or(configuration.prefix)(client, message)

client = commands.AutoShardedBot(
    command_prefix=prefix,
    case_insensitive=True,
    help_command=None,
    intents=configuration.intents,
    shard_count=configuration.shards,
    owner_ids=[717206196091617292]
)

client.start_time = datetime.utcnow()

cogs = []#"jishaku"
cogs.extend(load("cogs/events"))
cogs.extend(load("cogs/commands"))
client.load_extension('jishaku')

for cog in cogs:
    try:
        client.load_extension(cog)
        logging.info("Successfully loaded the \"%s\" cog" % (cog))
    except Exception as e:
        logging.error("Failed to load \"%s\" with error: %s" % (cog, e))

client.run(configuration.token)
